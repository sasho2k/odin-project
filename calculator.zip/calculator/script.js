// Init variables.
let firstNumber = null, secondNumber = null, operator = "", resultDisplayed = 0;

// Calculation functions.
function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

function divide(a, b) {
    return a / b;
}

// take two numbers and an operator and return the result.
function operate(a, b, operator) {
    switch (operator) {
        case "+":
            return add(a, b);
        case "-":
            return subtract(a, b);
        case "x":
            return multiply(a, b);
        case "/":
            return divide(a, b);
    }
}

// Set display text.
function setText(text) {
    document.getElementById("input-display").value = text;
}

// Get display text.
function getText() {
    return document.getElementById("input-display").value;
}

// Logic to correctly calculate multioperation statements.
function numberLogic(givenOperator) {
    operator = givenOperator;

    setText("");

    // Both numbers are empty
    if (firstNumber === null && secondNumber === null) {
        firstNumber = Number(getText());
    }

    // Second number is empty
    if (firstNumber !== null && secondNumber === null) {
        secondNumber = Number(getText());
    }

    // Neither numbers are empty
    if (firstNumber !== null && secondNumber !== null) {
        firstNumber = operate(firstNumber, secondNumber, operator);
        secondNumber = null;
    }
}

// Button press switch statement that holds base logic.
function pressButton(value) {
    switch (value) {
        // Clear calculator
        case "c":
            firstNumber = null, secondNumber = null, operator = "";
            setText("");

            console.log(`CLEAR - 1st num: ${firstNumber}, 2nd num: ${secondNumber}, operator: ${operator}, getText: ${getText()}`);

            break;
        // Beginning of operator logic.
        case "+":
        case "-":
        case "x":
        case "/":
            numberLogic(value);
            break;
        case "=":
            result = operate(firstNumber, secondNumber, operator);
            setText(Number(result));
            resultDisplayed = 1;
            break;
        default:
            // If not an operator, add text to display text.
            // Mimics "typing".
            if (resultDisplayed === 1) {
                setText("");
                resultDisplayed = 0;
            }
            else {
                text = getText();
                setText(text + value);
                break;
            }

    }
}